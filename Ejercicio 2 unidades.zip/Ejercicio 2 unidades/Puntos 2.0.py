import csv
import math
import re
import unicodedata
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import pymupdf


CARPETA_BASE = Path(__file__).resolve().parent
CARPETA_ESTUDIANTES = CARPETA_BASE / "Estudiantes"
CARPETA_CLAVES = CARPETA_BASE / "Claves"
CARPETA_PDF = CARPETA_BASE / "Hojas_IFEX"
CARPETA_ESCANEOS = CARPETA_BASE / "Escaneos_IFEX"
CARPETA_RESULTADOS = CARPETA_BASE / "Resultados_IFEX"
ANCHO, ALTO, ESCALA = 595, 842, 2
TAMANO_QR = 68
QR_X, QR_Y = ANCHO - 42 - TAMANO_QR, 38
OPCIONES = ("A", "B", "C", "D")
EXTENSIONES_IMAGEN = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}


class DatosExamen:
    def __init__(self, archivo_estudiantes, archivo_claves):
        self.archivos = (archivo_estudiantes, archivo_claves)


    def cargar(self):
        filas_estudiantes = self._leer_csv(self.archivos[0])
        filas_claves = self._leer_csv(self.archivos[1])
        columnas_estudiantes = self._columnas(
            filas_estudiantes[0], ("nombre", "curso", "id", "clave")
        )
        columnas_claves = self._columnas(
            filas_claves[0],
            ("numero de pregunta", "respuesta correcta", "tipo de clave"),
        )

        estudiantes = {}
        for fila in filas_estudiantes:
            id_estudiante = fila[columnas_estudiantes[2]].strip()
            clave = fila[columnas_estudiantes[3]].strip().upper()
            if not id_estudiante or not clave:
                raise ValueError("Hay un estudiante sin ID o sin tipo de clave.")
            if id_estudiante in estudiantes:
                raise ValueError(f"El ID está repetido: {id_estudiante}")
            estudiantes[id_estudiante] = {
                "id": id_estudiante,
                "nombre": fila[columnas_estudiantes[0]].strip(),
                "curso": fila[columnas_estudiantes[1]].strip(),
                "clave": clave,
            }

        claves = {}
        for fila in filas_claves:
            clave = fila[columnas_claves[2]].strip().upper()
            try:
                numero = int(fila[columnas_claves[0]])
            except ValueError as error:
                raise ValueError("Hay un número de pregunta inválido.") from error
            respuesta = fila[columnas_claves[1]].strip().upper()
            if numero < 1 or respuesta not in OPCIONES:
                raise ValueError(f"Pregunta o respuesta inválida: {numero}, {respuesta}")
            respuestas = claves.setdefault(clave, {})
            if numero in respuestas:
                raise ValueError(f"Pregunta {numero} repetida en la clave {clave}.")
            respuestas[numero] = respuesta

        self._validar(estudiantes, claves)
        return estudiantes, claves


    @staticmethod
    def _leer_csv(ruta):
        with ruta.open(encoding="utf-8-sig", newline="") as archivo:
            filas = list(csv.DictReader(archivo))
        if not filas:
            raise ValueError(f"El archivo no contiene registros: {ruta.name}")
        return filas


    @staticmethod
    def _normalizar(texto):
        texto = unicodedata.normalize("NFKD", texto.strip().lower())
        return "".join(c for c in texto if not unicodedata.combining(c))


    @classmethod
    def _columnas(cls, fila, esperadas):
        nombres = {cls._normalizar(nombre): nombre for nombre in fila}
        resultado = []
        for esperado in esperadas:
            encontrado = next(
                (original for normalizado, original in nombres.items()
                 if normalizado.startswith(esperado)),
                None,
            )
            if encontrado is None:
                raise ValueError(f"Falta una columna del tipo '{esperado}'.")
            resultado.append(encontrado)
        return resultado


    @staticmethod
    def _validar(estudiantes, claves):
        if not claves:
            raise ValueError("No hay claves de respuesta.")
        preguntas_base = set(next(iter(claves.values())))
        for nombre, respuestas in claves.items():
            if set(respuestas) != preguntas_base or preguntas_base != set(
                range(1, len(respuestas) + 1)
            ):
                raise ValueError(f"Preguntas incompletas o distintas en clave {nombre}.")
            if len(respuestas) > 100:
                raise ValueError(f"La clave {nombre} supera las 100 preguntas.")
        for estudiante in estudiantes.values():
            if estudiante["clave"] not in claves:
                raise ValueError(
                    f"No existe la clave {estudiante['clave']} "
                    f"del estudiante {estudiante['id']}."
                )


class GeneradorHojas:
    def __init__(self, carpeta_salida=CARPETA_PDF):
        self.carpeta_salida = carpeta_salida


    def crear(self, estudiantes, claves):
        carpeta_generacion = self._crear_carpeta_generacion()
        documento = pymupdf.open()
        for estudiante in estudiantes.values():
            self._crear_pdf(documento, estudiante, claves[estudiante["clave"]])
        ruta_pdf = carpeta_generacion / "Hojas_IFEX.pdf"
        documento.save(ruta_pdf)
        documento.close()
        print(f"Hojas creadas: {len(estudiantes)}. PDF: {ruta_pdf}")


    def _crear_carpeta_generacion(self):
        self.carpeta_salida.mkdir(parents=True, exist_ok=True)
        numeros = [
            int(coincidencia.group(1))
            for carpeta in self.carpeta_salida.iterdir()
            if carpeta.is_dir()
            and (coincidencia := re.match(r"(\d+)-", carpeta.name))
        ]
        numero = max(numeros, default=0) + 1
        fecha_hora = datetime.now().strftime("%m-%d-%Y-%I-%M %p")
        carpeta = self.carpeta_salida / f"{numero}-{fecha_hora}"
        carpeta.mkdir()
        return carpeta


    def _crear_pdf(self, documento, estudiante, respuestas):
        pagina = documento.new_page(width=ANCHO, height=ALTO)
        pagina.insert_text((42, 57), "HOJA DE RESPUESTAS - IFEX", fontsize=17)
        pagina.insert_text((42, 82), f"Estudiante: {estudiante['nombre']}", fontsize=11)
        pagina.insert_text(
            (42, 101),
            f"ID: {estudiante['id']}  Curso: {estudiante['curso']}  "
            f"Clave: {estudiante['clave']}",
            fontsize=10,
        )
        pagina.insert_text(
            (42, 126), "Rellena una burbuja por pregunta. No marques el QR.", fontsize=8
        )
        rectangulo = pymupdf.Rect(QR_X, QR_Y, QR_X + TAMANO_QR, QR_Y + TAMANO_QR)
        contenido = f"IFEX:v1:{estudiante['id']}:{estudiante['clave']}"
        pagina.insert_image(rectangulo, stream=self._crear_qr(contenido))
        self._dibujar_preguntas(pagina, respuestas)
        pagina.draw_line((42, 143), (ANCHO - 42, 143), color=(0.5, 0.5, 0.5))


    @staticmethod
    def _crear_qr(contenido):
        qr = cv2.QRCodeEncoder_create().encode(contenido)
        exito, imagen = cv2.imencode(".png", qr)
        if not exito:
            raise RuntimeError("No se pudo crear el código QR.")
        return imagen.tobytes()


    @staticmethod
    def _dibujar_preguntas(pagina, respuestas):
        numeros = sorted(respuestas)
        filas = math.ceil(len(numeros) / 2)
        espacio = min(13, (ALTO - 198) / max(filas, 1))
        for columna, x in enumerate((42, 306)):
            pagina.insert_text((x + 42, 158), "A       B       C       D", fontsize=7)
            for fila, numero in enumerate(numeros[columna * filas:(columna + 1) * filas]):
                y = 175 + fila * espacio
                pagina.insert_text((x, y + 2.5), f"{numero:03}", fontsize=7)
                for opcion in range(4):
                    pagina.draw_circle((x + 48 + opcion * 22, y), 4, width=0.7)


class LectorEscaneos:
    def __init__(self):
        self.detector_qr = cv2.QRCodeDetector()


    def paginas(self, ruta):
        if ruta.suffix.lower() == ".pdf":
            documento = pymupdf.open(ruta)
            try:
                for indice, pagina in enumerate(documento):
                    pixmap = pagina.get_pixmap(matrix=pymupdf.Matrix(ESCALA, ESCALA))
                    imagen = np.frombuffer(pixmap.samples, np.uint8)
                    imagen = imagen.reshape(pixmap.height, pixmap.width, pixmap.n)
                    yield f"{ruta.name}, página {indice + 1}", cv2.cvtColor(
                        imagen, cv2.COLOR_RGB2BGR
                    )
            finally:
                documento.close()
        elif ruta.suffix.lower() in EXTENSIONES_IMAGEN:
            imagen = cv2.imread(str(ruta))
            if imagen is None:
                raise ValueError(f"No se pudo leer {ruta.name}.")
            yield ruta.name, imagen
        else:
            raise ValueError(f"Formato no compatible: {ruta.name}")


    def respuestas(self, imagen, claves):
        gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
        contenido, puntos, _ = self.detector_qr.detectAndDecode(gris)
        coincidencia = re.fullmatch(r"IFEX:v1:([^:]+):([^:]+)", contenido or "")
        if not coincidencia or puntos is None:
            raise ValueError("No se encontró un QR IFEX legible.")
        id_estudiante, tipo_clave = coincidencia.groups()
        tipo_clave = tipo_clave.upper()
        if tipo_clave not in claves:
            raise ValueError(f"No existe la clave {tipo_clave}.")
        alineada = self._alinear(imagen, puntos.reshape(4, 2))
        clave = claves[tipo_clave]
        marcadas = self._leer_burbujas(alineada, len(clave))
        correctas = sum(marcadas[n] == r for n, r in clave.items())
        blancas = sum(not respuesta for respuesta in marcadas.values())
        return id_estudiante, tipo_clave, {
            "correctas": correctas,
            "incorrectas": len(marcadas) - correctas - blancas,
            "sin_responder": blancas,
            "total": len(marcadas),
        }


    @staticmethod
    def _alinear(imagen, puntos):
        margen = TAMANO_QR * 2 / 25
        x1, y1 = round((QR_X + margen) * ESCALA), round((QR_Y + margen) * ESCALA)
        tamano = round((TAMANO_QR - 2 * margen) * ESCALA) - 1
        x2, y2 = x1 + tamano, y1 + tamano
        destino = np.float32(((x1, y1), (x2, y1), (x2, y2), (x1, y2)))
        matriz = cv2.getPerspectiveTransform(puntos.astype(np.float32), destino)
        return cv2.warpPerspective(imagen, matriz, (ANCHO * ESCALA, ALTO * ESCALA))


    @staticmethod
    def _leer_burbujas(imagen, cantidad):
        gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
        filas = math.ceil(cantidad / 2)
        espacio = min(13, (ALTO - 198) / max(filas, 1))
        respuestas = {}
        radio = round(2.4 * ESCALA)
        yy, xx = np.ogrid[-radio:radio + 1, -radio:radio + 1]
        mascara = xx * xx + yy * yy <= radio * radio

        for numero in range(1, cantidad + 1):
            columna, fila = (numero - 1) // filas, (numero - 1) % filas
            x = (42, 306)[columna]
            centro_y = round((175 + fila * espacio) * ESCALA)
            opciones = []
            for indice, opcion in enumerate(OPCIONES):
                centro_x = round((x + 48 + indice * 22) * ESCALA)
                recorte = gris[
                    centro_y - radio:centro_y + radio + 1,
                    centro_x - radio:centro_x + radio + 1,
                ]
                if recorte.size and np.mean(recorte[mascara] < 180) >= 0.25:
                    opciones.append(opcion)
            respuestas[numero] = opciones[0] if len(opciones) == 1 else (
                "MULTIPLE" if opciones else ""
            )
        return respuestas


class AplicacionIFEX:
    def __init__(self):
        self.generador = GeneradorHojas()
        self.lector = LectorEscaneos()
        CARPETA_ESCANEOS.mkdir(parents=True, exist_ok=True)


    def ejecutar(self):
        while True:
            print("\n=== Sistema de hojas IFEX ===\n1. Elegir archivos CSV\n2. Salir")
            opcion = input("Elige una opción: ").strip()
            if opcion == "2":
                return
            if opcion != "1":
                print("Opción inválida."); continue
            try:
                archivo_estudiantes = self._elegir_csv(CARPETA_ESTUDIANTES, "estudiantes")
                if archivo_estudiantes is None: continue
                archivo_claves = self._elegir_csv(CARPETA_CLAVES, "claves")
                if archivo_claves is None: continue
                estudiantes, claves = DatosExamen(archivo_estudiantes, archivo_claves).cargar()
                self._menu_examen(estudiantes, claves)
            except (FileNotFoundError, ValueError, RuntimeError) as error:
                print(f"No se pudo completar: {error}")


    @staticmethod
    def _elegir_csv(carpeta, tipo):
        archivos = sorted(carpeta.glob("*.csv"))
        if not archivos:
            raise FileNotFoundError(f"No hay CSV en la carpeta {carpeta}.")
        print(f"\nArchivos de {tipo}:")
        for numero, archivo in enumerate(archivos, 1): print(f"{numero}. {archivo.name}")
        try: opcion = int(input("Elige un archivo (0 para volver): "))
        except ValueError: return None
        return archivos[opcion - 1] if 1 <= opcion <= len(archivos) else None


    def _menu_examen(self, estudiantes, claves):
        while True:
            opcion = input("\n1. Crear PDF\n2. Calificar escaneos\n0. Cambiar archivos\nElige: ").strip()
            if opcion == "0": return
            try:
                if opcion == "1": self.generador.crear(estudiantes, claves)
                elif opcion == "2": self._calificar(estudiantes, claves)
                else: print("Opción inválida.")
            except (FileNotFoundError, ValueError, RuntimeError) as error:
                print(f"No se pudo completar: {error}")


    def _calificar(self, estudiantes, claves):
        texto = input(
            f"Ruta del PDF o carpeta de escaneos "
            f"(Enter para usar {CARPETA_ESCANEOS}): "
        ).strip().strip('"')
        origen = Path(texto) if texto else CARPETA_ESCANEOS
        rutas = [origen] if origen.is_file() else (
            sorted(p for p in origen.iterdir() if p.suffix.lower() == ".pdf"
                   or p.suffix.lower() in EXTENSIONES_IMAGEN)
            if origen.is_dir() else []
        )
        if not rutas:
            raise FileNotFoundError(f"No hay archivos compatibles en: {origen}")

        resultados, errores = {}, []
        for ruta in rutas:
            try:
                for nombre, imagen in self.lector.paginas(ruta):
                    try:
                        id_estudiante, tipo, conteo = self.lector.respuestas(
                            imagen, claves
                        )
                        if id_estudiante not in estudiantes:
                            raise ValueError(f"ID no registrado: {id_estudiante}")
                        if estudiantes[id_estudiante]["clave"] != tipo:
                            raise ValueError("La clave del QR no coincide con el estudiante.")
                        if id_estudiante in resultados:
                            raise ValueError(f"El estudiante {id_estudiante} está repetido.")
                        resultados[id_estudiante] = conteo
                        print(
                            f"{estudiantes[id_estudiante]['nombre']} ({id_estudiante}): "
                            f"{conteo['correctas']} correctas, "
                            f"{conteo['incorrectas']} incorrectas, "
                            f"{conteo['sin_responder']} sin responder."
                        )
                    except (ValueError, cv2.error) as error:
                        errores.append({"archivo": nombre, "error": str(error)})
                        print(f"Error en {nombre}: {error}")
            except (OSError, pymupdf.FileDataError, ValueError) as error:
                errores.append({"archivo": ruta.name, "error": str(error)})
                print(f"Error en {ruta.name}: {error}")
        self._guardar_resultados(estudiantes, resultados, errores)


    @staticmethod
    def _guardar_resultados(estudiantes, resultados, errores):
        CARPETA_RESULTADOS.mkdir(exist_ok=True)
        ruta = CARPETA_RESULTADOS / "resultados.csv"
        columnas = [
            "ID", "Nombre", "Curso", "Clave", "Correctas",
            "Incorrectas", "Sin responder", "Total", "Estado",
        ]
        with ruta.open("w", newline="", encoding="utf-8-sig") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=columnas)
            escritor.writeheader()
            for id_estudiante, estudiante in estudiantes.items():
                conteo = resultados.get(id_estudiante, {})
                escritor.writerow({
                    "ID": id_estudiante,
                    "Nombre": estudiante["nombre"],
                    "Curso": estudiante["curso"],
                    "Clave": estudiante["clave"],
                    "Correctas": conteo.get("correctas", ""),
                    "Incorrectas": conteo.get("incorrectas", ""),
                    "Sin responder": conteo.get("sin_responder", ""),
                    "Total": conteo.get("total", ""),
                    "Estado": "Procesado" if conteo else "Sin escanear",
                })
        ruta_errores = CARPETA_RESULTADOS / "errores.csv"
        with ruta_errores.open("w", newline="", encoding="utf-8-sig") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=["archivo", "error"])
            escritor.writeheader()
            escritor.writerows(errores)
        print(f"Resultados guardados en: {ruta}")
        if errores:
            print(f"Errores guardados en: {ruta_errores}")

if __name__ == "__main__":
    AplicacionIFEX().ejecutar()
